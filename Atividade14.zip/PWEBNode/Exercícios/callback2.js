//Não terminado
function exibeMensagensNaOrdem(mensagem, callback){
    console.log(mensagem);
    callback();
}

exibeMensagensNaOrdem('Essa é a primeira mensagem exibida no ordem',
function(){
    console.log('Essa é a segunda mensagem exibida no ordem');